<?php
$host = 'localhost';
$username = 'marketf7_lokesh';
$password = '#Xka1ZJ$&QC[';
$database = 'marketf7_mailspot';
$dbconfig = mysqli_connect($host,$username,$password,$database) or die("An Error occured when connecting to the database");
?>