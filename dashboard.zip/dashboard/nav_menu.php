
 <aside class="left-sidebar" data-sidebarbg="skin5">
            <!-- Sidebar scroll-->
            <div class="scroll-sidebar">
                <!-- Sidebar navigation-->
                <nav class="sidebar-nav">
                    <ul id="sidebarnav">
                        
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/iimnet_internship_view"
                                aria-expanded="false">
                                 <i class="fa fa-home" aria-hidden="true"></i>
                                <span class="hide-menu">IIMnet Internship Details</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/iimnet_freelancing_view"
                                aria-expanded="false">
                                 <i class="fa fa-home" aria-hidden="true"></i>
                                <span class="hide-menu">IIMnet Freelancing Details</span>
                            </a>
                        </li>
                          <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/get-help-view"
                                aria-expanded="false">
                                 <i class="fa fa-home" aria-hidden="true"></i>
                                <span class="hide-menu">IIMnet COVID-19 Get Help</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/get_help_details_view"
                                aria-expanded="false">
                                 <i class="fa fa-home" aria-hidden="true"></i>
                                <span class="hide-menu">IIMnet COVID-19 Get Help Details</span>
                            </a>
                        </li>
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/volunteer_view"
                                aria-expanded="false">
                                 <i class="fa fa-home" aria-hidden="true"></i>
                                <span class="hide-menu">IIMnet Volunteers Details</span>
                            </a>
                        </li>
                          <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/mba_view"
                                aria-expanded="false">
                                 <i class="fa fa-home" aria-hidden="true"></i>
                                <span class="hide-menu">IIMnet MBA Details</span>
                            </a>
                        </li>
                        
                        <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/user_list"
                                aria-expanded="false">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <span class="hide-menu">Users List</span>
                            </a>
                        </li>
                         <li class="sidebar-item">
                            <a class="sidebar-link waves-effect waves-dark sidebar-link" href="https://iimnet.com/dashboard/contact-view"
                                aria-expanded="false">
                                <i class="fa fa-user" aria-hidden="true"></i>
                                <span class="hide-menu">Contact Details</span>
                            </a>
                        </li>
                        
                     
                </nav>
                <!-- End Sidebar navigation -->
            </div>
            <!-- End Sidebar scroll-->
        </aside>
